from django import forms
from django.core.validators import RegexValidator
from django.contrib.auth.forms import UserCreationForm
from .models import User, CleaningRequest


class RegisterForm(UserCreationForm):
    email = forms.EmailField()
    full_name = forms.CharField(max_length=255)
    phone = forms.CharField(
        validators=[RegexValidator(r'^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$')]
    )

    class Meta:
        model = User
        fields = ("username", "full_name", "phone", "email", "password1", "password2")


class CleaningRequestForm(forms.ModelForm):
    class Meta:
        model = CleaningRequest
        exclude = ('user', 'status', 'cancellation_reason', 'created_at')
