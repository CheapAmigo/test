from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required, user_passes_test
from .forms import RegisterForm, CleaningRequestForm
from .models import CleaningRequest


def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = RegisterForm()
    return render(request, 'core/register.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('create_request')
    return render(request, 'core/login.html')


@login_required
def create_request_view(request):
    requests = CleaningRequest.objects.filter(user=request.user)
    return render(request, 'core/create_request.html', {'requests': requests})


@login_required
def request_form_view(request):
    if request.method == 'POST':
        form = CleaningRequestForm(request.POST)
        if form.is_valid():
            req = form.save(commit=False)
            req.user = request.user
            req.save()
            return redirect('create_request')
    else:
        form = CleaningRequestForm()
    return render(request, 'core/request_form.html', {'form': form})


def is_admin(user):
    return user.username == 'adminka'


@user_passes_test(is_admin)
def admin_panel_view(request):
    requests = CleaningRequest.objects.all()
    return render(request, 'core/admin_panel.html', {'requests': requests})
