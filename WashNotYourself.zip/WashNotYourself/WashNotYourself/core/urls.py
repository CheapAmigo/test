from django.urls import path
from .views import (
    register_view,
    login_view,
    create_request_view,
    request_form_view,
    admin_panel_view,
)

urlpatterns = [
    path('register/', register_view, name='register'),
    path('login/', login_view, name='login'),
    path('create/', create_request_view, name='create_request'),
    path('form/', request_form_view, name='request_form'),
    path('admin-panel/', admin_panel_view, name='admin_panel'),
]
