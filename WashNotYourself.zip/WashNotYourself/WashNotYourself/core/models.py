from django.contrib.auth.models import AbstractUser, Group, Permission
from django.db import models
from django.utils import timezone
from django.core.validators import RegexValidator

class User(AbstractUser):
    phone = models.CharField(
        max_length=20,
        validators=[RegexValidator(r'^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$')],
    )
    full_name = models.CharField(max_length=255)

    # Переопределяем поля groups и user_permissions с уникальными related_name
    groups = models.ManyToManyField(
        Group,
        related_name="custom_user_set",  # меняем related_name
        blank=True,
        help_text="The groups this user belongs to.",
        verbose_name="groups",
    )
    user_permissions = models.ManyToManyField(
        Permission,
        related_name="custom_user_set",  # меняем related_name
        blank=True,
        help_text="Specific permissions for this user.",
        verbose_name="user permissions",
    )

    def __str__(self):
        return self.username


class Service(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class CleaningRequest(models.Model):
    STATUS_CHOICES = [
        ('new', 'Новая'),
        ('in_progress', 'В работе'),
        ('done', 'Выполнено'),
        ('cancelled', 'Отменено'),
    ]

    PAYMENT_CHOICES = [
        ('cash', 'Наличные'),
        ('card', 'Банковская карта'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    address = models.TextField()
    contact_phone = models.CharField(
        max_length=20,
        validators=[RegexValidator(r'^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$')],
    )
    contact_email = models.EmailField()
    service = models.ForeignKey(Service, on_delete=models.SET_NULL, null=True, blank=True)
    custom_service = models.CharField(max_length=255, blank=True)
    preferred_time = models.DateTimeField()
    payment_type = models.CharField(max_length=10, choices=PAYMENT_CHOICES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='new')
    cancellation_reason = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"Заявка от {self.user.full_name} — {self.get_status_display()}"

    def is_custom_service(self):
        return self.service is None and bool(self.custom_service)
